package com.tns.stp.entities;

public class Customer {

	private int customerID;
	private String name;
	private int contact;
	private String address;
	//constructor
	public Customer(int customerID, String name, int contact, String address) {
		super();
		this.customerID = customerID;
		this.name = name;
		this.contact = contact;
		this.address = address;
	}
	
	//getters and setters

	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getContact() {
		return contact;
	}
	public void setContact(int contact) {
		this.contact = contact;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	//to string method

	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", name=" + name + ", contact=" + contact + ", address=" + address
				+ "]";
	}
	
	
	
	
	
	
	
	
	
	
}
